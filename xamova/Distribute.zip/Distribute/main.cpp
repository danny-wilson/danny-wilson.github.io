#include <string>
#include <random.h>
#include <map>
#include <tsv.h>
#include <myerror.h>
#include <iomanip>

using namespace std;
using namespace myutils;

int main(const int argc, const char* argv[]) {
	class Random ran;											// Needed for the permutation test
	if(argc<2 | argc>4) error("SYNTAX: xamova filename [nperm [seed]]");
	const char* fname = argv[1];
	int T = 1000;												// Number of permutations for each factor
	if(argc>2) {
		T = atoi(argv[2]);
		if(T<100) error("Must have at least 100 permutations");
	}
	cout << "Simulating " << T << " permutations" << endl;
	if(argc==4) {
		const int seed = atoi(argv[3]);
		ran.setseed(seed);
	}
	cout << "Set seed to " << ran.getseed() << endl;
	
	tsv data(100000);
	cout << "Reading " << fname << endl;
	data.read(fname);
	// Assume the following file format
	//		Column 1:			Integers starting from 1, denote level for first factor
	//		Column 2:			Integers starting from 1, denote level for second factor
	//		Subsequently:		Strings denoting the marker haplotype at each locus or site
	if(data.data.ncols()<3) error("File must have at least three columns: factor 1, factor 2 and haplotype columns");

	const int factor1 = 0;
	string factor1name = data.fieldname[0];
	const int factor2 = 1;
	string factor2name = data.fieldname[1];
	const int nloc = data.data.ncols()-2;

	int i,j,k,ii,jj,kk,loc;
	cout << "Levels for first factor (" << factor1name << "):";
	map<string,int> ccode;								// ccode converts factor 1 levels to integers
	for(i=0;i<data.fieldvalue[factor1].size();i++) {
		string val = data.fieldvalue[factor1][i];
		if(i>0) cout << ",";
		cout << " " << val;
		ccode[val] = i+1;
	}
	cout << endl;
	const int i_levels = i;								// number of levels for factor 1
	cout << "Levels for second factor (" << factor2name << "):";
	map<string,int> dcode;								// dcode converts factor 2 levels to integers
	for(i=0;i<data.fieldvalue[factor2].size();i++) {
		string val = data.fieldvalue[factor2][i];
		if(i>0) cout << ",";
		cout << " " << val;
		dcode[val] = i+1;
	}
	cout << endl << endl;
	const int j_levels = i;

	int** n=new int*[i_levels+1];								// n[i][j] is the sample size for i and j
	int** nn=new int*[i_levels+1];
	for(i=0;i<i_levels+1;i++)
	{
		n[i]=new int[j_levels+1];
		nn[i]=new int[j_levels+1];
		for(j=0;j<j_levels+1;j++)
		{
			n[i][j]=0;
			nn[i][j]=0;
		}
	}

	// Count the combinations of levels
	for(i=0;i<data.data.nrows();i++)
		++n[ccode[data.data[i][factor1]]][dcode[data.data[i][factor2]]];
	int N=0;													// N is the total sample size
	for(i=0;i<i_levels;i++)
		for(j=0;j<j_levels;j++)
		{
			n[i][j]=n[i+1][j+1];
			N+=n[i][j];
		}

	// Formating considerations:
	int swidth = data.fieldvalue[factor1][0].length();
	for(i=1;i<data.fieldvalue[factor1].size();i++) swidth = max(swidth,(int)data.fieldvalue[factor1][i].length());
	int nwidth = (int)log10(N)+1;
	for(i=0;i<data.fieldvalue[factor2].size();i++) nwidth = max(nwidth,(int)data.fieldvalue[factor2][i].length());
	nwidth += 2;
	cout << "Sample sizes:" << endl;
	cout << setw(swidth) << "" << " ";
	for(j=0;j<j_levels;j++) cout << setw(nwidth) << data.fieldvalue[factor2][j];
	cout << endl;
	for(i=0;i<i_levels;i++) {
		cout << setw(swidth) << data.fieldvalue[factor1][i] << ":";
		for(j=0;j<j_levels;j++) {
			cout << setw(nwidth) << n[i][j];
		}
		cout << endl;
	}
	cout << endl;



	/***************************************************************/
	int*** Y=new int**[i_levels];									// Y[i][j][k] stores the sequence identity for the kth replicate
	for(i=0;i<i_levels;i++)										// with levels i and j
	{
		Y[i]=new int*[j_levels];
		for(j=0;j<j_levels;j++)
			Y[i][j]=new int[n[i][j]];
	}

	for(i=0;i<data.data.nrows();i++)
	{
		int co=ccode[data.data[i][factor1]]-1;
		int dco=dcode[data.data[i][factor2]]-1;
		if((co>=0)&&(dco>=0)) {
			Y[co][dco][nn[co][dco]]=i;
			++nn[co][dco];
		}
	}

	int****** delta=new int*****[i_levels];						// delta[i][j][k][ii][jj][kk] store the number of pairwise
	int****** DELTA=new int*****[i_levels];						// differences between the kth replicate with levels i and j
	for(i=0;i<i_levels;i++)										// and the kkth replicate with levels ii and jj.
	{
		delta[i]=new int****[j_levels];							// DELTA is a temporary, mutable copy of delta
		DELTA[i]=new int****[j_levels];
		for(j=0;j<j_levels;j++)
		{
			delta[i][j]=new int***[n[i][j]];
			DELTA[i][j]=new int***[n[i][j]];
			for(k=0;k<n[i][j];k++)
			{
				delta[i][j][k]=new int**[i_levels];
				DELTA[i][j][k]=new int**[i_levels];
				for(ii=0;ii<i_levels;ii++)
				{
					delta[i][j][k][ii]=new int*[j_levels];
					DELTA[i][j][k][ii]=new int*[j_levels];
					for(jj=0;jj<j_levels;jj++)
					{
						delta[i][j][k][ii][jj]=new int[n[ii][jj]];
						DELTA[i][j][k][ii][jj]=new int[n[ii][jj]];
						for(kk=0;kk<n[ii][jj];kk++)
						{
							int &del = delta[i][j][k][ii][jj][kk];
							// Find the sequences for the comparison
							const int seq1 = Y[i][j][k];
							const int seq2 = Y[ii][jj][kk];
							// Calculate the sum of pairwise differences
							del=0;
							for(loc=0;loc<nloc;loc++) {
								del += (int)(data.data[seq1][2+loc]!=data.data[seq2][2+loc]);
							}
							DELTA[i][j][k][ii][jj][kk]=del;
						}
					}
				}
			}
		}
	}
	
	T *= 3;													// T/3 is the number of permutations for each factor
	int XA=0,XB=1,Error=2,Total=3;							// XA,XB,Error and Total are 4 codes 0..3 for parts of the ANOVA table
	double* df=new double[4];									// df stores degrees of freedom for the table
	df[XA]=i_levels-1;
	df[XB]=j_levels-1;
	df[Total]=N-1;
	df[Error]=df[Total]-df[XA]-df[XB];
	double* SS=new double[4];									// SS stores sum of squares
	double* AS=new double[4];									// AS stores adjusted sum of squares
	double* MS=new double[4];									// MS stores mean square
	double* F=new double[2];									// F stores the F statistic
	double* F_OBS=new double[2];								// F_OBS stores the observed value for F
	double** F_NULL=new double*[T];								// F_NULL is the permutation null distribution for F
	for(i=0;i<T;i++)
		F_NULL[i]=new double[2];
	double** P=new double*[3];/*3 types of permutation test*/	// P is the p value
	for(i=0;i<3;i++)
	{
		P[i]=new double[2];
		P[i][XA]=0.0;
		P[i][XB]=0.0;
	}
	double* sigma=new double[4];								// sigma is the variance component
	double* Z=new double[3];									// z is the coefficient of sigma in the EMS
	Z[XA]=0.0;
	for(j=0;j<j_levels;j++)
	{
		double numerator=0.0;
		double denominator=0.0;
		for(i=0;i<i_levels;i++){numerator+=n[i][j]*n[i][j];denominator+=n[i][j];}
		Z[XA]+=numerator/denominator;
	}
	Z[XA]=((double)N-Z[XA])/(double)(i_levels-1);
	Z[XB]=0.0;
	for(i=0;i<i_levels;i++)
	{
		double numerator=0.0;
		double denominator=0.0;
		for(j=0;j<j_levels;j++){numerator+=n[i][j]*n[i][j];denominator+=n[i][j];}
		Z[XB]+=numerator/denominator;
	}
	Z[XB]=((double)N-Z[XB])/(double)(j_levels-1);

	int** p_list=new int*[N];
	for(i=0;i<N;i++)
	{
		p_list[i]=new int[3];
		p_list[i][0]=0;p_list[i][1]=0;p_list[i][2]=0;
	}

	int* i_size=new int[i_levels];
	for(i=0;i<i_levels;i++)
	{
		i_size[i]=0;
		for(j=0;j<j_levels;j++)
			i_size[i]+=n[i][j];
	}
	int* j_size=new int[j_levels];
	for(j=0;j<j_levels;j++)
	{
		j_size[j]=0;
		for(i=0;i<i_levels;i++)
			j_size[j]+=n[i][j];
	}
	
	int*** pXA_list=new int**[j_levels];
	for(j=0;j<j_levels;j++)
	{
		pXA_list[j]=new int*[j_size[j]];
		for(i=0;i<j_size[j];i++)
		{
			pXA_list[j][i]=new int[3];
			pXA_list[j][i][0]=0;pXA_list[j][i][1]=0;pXA_list[j][i][2]=0;
		}
	}

	int*** pXB_list=new int**[i_levels];
	for(i=0;i<i_levels;i++)
	{
		pXB_list[i]=new int*[i_size[i]];
		for(j=0;j<i_size[i];j++)
		{
			pXB_list[i][j]=new int[3];
			pXB_list[i][j][0]=0;pXB_list[i][j][1]=0;pXB_list[i][j][2]=0;
		}
	}

	int**** permute_Y=new int***[i_levels];
	for(i=0;i<i_levels;i++)
	{
		permute_Y[i]=new int**[j_levels];
		for(j=0;j<j_levels;j++)
		{
			permute_Y[i][j]=new int*[n[i][j]];
			for(k=0;k<n[i][j];k++)
			{
				permute_Y[i][j][k]=new int[3];
				permute_Y[i][j][k][0]=0;
				permute_Y[i][j][k][1]=0;
				permute_Y[i][j][k][2]=0;
			}
		}
	}

	for(int t=-1;t<T;t++)										// on round t=-1 we calculate the observed values
	{
		SS[Total]=0.0;
		for(i=0;i<i_levels;i++)
			for(j=0;j<j_levels;j++)
				for(k=0;k<n[i][j];k++)
					for(ii=0;ii<i_levels;ii++)
						for(jj=0;jj<j_levels;jj++)
							for(kk=0;kk<n[ii][jj];kk++)
								SS[Total]+=DELTA[i][j][k][ii][jj][kk];
		SS[Total]/=2.0*N;
		SS[Error]=0.0;
		for(i=0;i<i_levels;i++)
			for(j=0;j<j_levels;j++)
			{
				double temp=0.0;
				for(k=0;k<n[i][j];k++)
					for(kk=0;kk<n[i][j];kk++)
						temp+=DELTA[i][j][k][i][j][kk];
				if(n[i][j]>0)/**/
					SS[Error]+=temp/2./n[i][j];
			}
		SS[XA]=0.0;
		for(i=0;i<i_levels;i++)
		{
			double temp=0.0;
			for(j=0;j<j_levels;j++)
				for(k=0;k<n[i][j];k++)
					for(jj=0;jj<j_levels;jj++)
						for(kk=0;kk<n[i][jj];kk++)
							temp+=DELTA[i][j][k][i][jj][kk];
			double group_size=0.0;
			for(j=0;j<j_levels;j++)group_size+=n[i][j];
			if(group_size>0.0)/**/
				SS[XA]+=temp/2.0/group_size;
		}
		SS[XA]=SS[Total]-SS[XA];
		SS[XB]=SS[Total]-SS[Error]-SS[XA];
		AS[XB]=SS[XB];
		AS[XA]=0.0;
		for(j=0;j<j_levels;j++)
		{
			double temp=0.0;
			for(i=0;i<i_levels;i++)
				for(k=0;k<n[i][j];k++)
					for(ii=0;ii<i_levels;ii++)
						for(kk=0;kk<n[ii][j];kk++)
							temp+=DELTA[i][j][k][ii][j][kk];
			double group_size=0.0;
			for(i=0;i<i_levels;i++)group_size+=n[i][j];
			if(group_size>0.0)
				AS[XA]+=temp/2.0/group_size;
		}
		AS[XA]-=SS[Error];
		AS[Error]=SS[Error];

		MS[XA]=AS[XA]/df[XA];									// we are using ADJUSTED mean squares
		MS[XB]=AS[XB]/df[XB];
		MS[Error]=AS[Error]/df[Error];
		F[XA]=MS[XA]/MS[Error];/*Both F tests use the Error MS for a denominator*/
		F[XB]=MS[XB]/MS[Error];
		sigma[XA]=(MS[XA]-MS[Error])/Z[XA];
		sigma[XB]=(MS[XB]-MS[Error])/Z[XB];
		sigma[Error]=MS[Error];
		sigma[Total]=sigma[XA]+sigma[XB]+sigma[Error];

		if(t==-1)
		{
			printf("ANOVA Table\n\n");
			printf("      %4s %9s %9s %9s %9s %9s %9s \n","df","Seq SS","Adj SS","MS","F","n","var");
			printf("XA    %4g %9.5g %9.5g %9.5g %9.5g %9.5g %9.5g\n",df[XA],SS[XA],AS[XA],MS[XA],F[XA],Z[XA],sigma[XA]);
			printf("XB    %4g %9.5g %9.5g %9.5g %9.5g %9.5g %9.5g\n",df[XB],SS[XB],AS[XB],MS[XB],F[XB],Z[XB],sigma[XB]);
			printf("Error %4g %9.5g %9.5g %9.5g %9s %9s %9.5g\n",df[Error],SS[Error],AS[Error],MS[Error],"","",sigma[Error]);
			printf("Total %4g %9.5g %9s %9s %9s %9s %9.5g\n\n",df[Total],SS[Total],"","","","",sigma[Total]);
			printf("where XA = %s, XB = %s\n",factor1name.c_str(),factor2name.c_str());
			F_OBS[XA]=F[XA];
			F_OBS[XB]=F[XB];
		}
		else
		{
			int p_type=t%3;
			F_NULL[t][XA]=F[XA];
			F_NULL[t][XB]=F[XB];
			if(F[XA]<F_OBS[XA])++P[p_type][XA];
			if(F[XB]<F_OBS[XB])++P[p_type][XB];
		}

		if((t+1)%3==0)
		{
			/*permute XAs not XBs*/
			for(j=0;j<j_levels;j++)
			{
				int p_list_counter=0;
				for(i=0;i<i_levels;i++)
					for(k=0;k<n[i][j];k++)
					{
						pXA_list[j][p_list_counter][0]=i;
						pXA_list[j][p_list_counter][1]=j;
						pXA_list[j][p_list_counter][2]=k;
						++p_list_counter;
					}
			}
			for(j=0;j<j_levels;j++)
			{
				int p_list_length=j_size[j];
				for(i=0;i<i_levels;i++)
					for(k=0;k<n[i][j];k++)
					{
						int rnum1=ran.discrete(0,p_list_length-1);
						permute_Y[i][j][k][0]=pXA_list[j][rnum1][0];
						permute_Y[i][j][k][1]=pXA_list[j][rnum1][1];
						permute_Y[i][j][k][2]=pXA_list[j][rnum1][2];
						pXA_list[j][rnum1][0]=pXA_list[j][p_list_length-1][0];
						pXA_list[j][rnum1][1]=pXA_list[j][p_list_length-1][1];
						pXA_list[j][rnum1][2]=pXA_list[j][p_list_length-1][2];
						--p_list_length;
					}
			}
		}
		else if((t+1)%3==1)
		{
			/*permute XBs not XAs*/
			for(i=0;i<i_levels;i++)
			{
				int p_list_counter=0;
				for(j=0;j<j_levels;j++)
					for(k=0;k<n[i][j];k++)
					{
						pXB_list[i][p_list_counter][0]=i;
						pXB_list[i][p_list_counter][1]=j;
						pXB_list[i][p_list_counter][2]=k;
						++p_list_counter;
					}
			}
			for(i=0;i<i_levels;i++)
			{
				int p_list_length=i_size[i];
				for(j=0;j<j_levels;j++)
					for(k=0;k<n[i][j];k++)
					{
						int rnum1=ran.discrete(0,p_list_length-1);
						permute_Y[i][j][k][0]=pXB_list[i][rnum1][0];
						permute_Y[i][j][k][1]=pXB_list[i][rnum1][1];
						permute_Y[i][j][k][2]=pXB_list[i][rnum1][2];
						pXB_list[i][rnum1][0]=pXB_list[i][p_list_length-1][0];
						pXB_list[i][rnum1][1]=pXB_list[i][p_list_length-1][1];
						pXB_list[i][rnum1][2]=pXB_list[i][p_list_length-1][2];
						--p_list_length;
					}
			}
		}
		else if((t+1)%3==2)
		{
			/*Permute both*/
			int p_list_counter=0;
			for(i=0;i<i_levels;i++)
				for(j=0;j<j_levels;j++)
					for(k=0;k<n[i][j];k++)
					{
						p_list[p_list_counter][0]=i;
						p_list[p_list_counter][1]=j;
						p_list[p_list_counter][2]=k;
						++p_list_counter;
					}

			int p_list_length=N;
			for(i=0;i<i_levels;i++)
				for(j=0;j<j_levels;j++)
					for(k=0;k<n[i][j];k++)
					{
						int rnum1=ran.discrete(0,p_list_length-1);
						permute_Y[i][j][k][0]=p_list[rnum1][0];
						permute_Y[i][j][k][1]=p_list[rnum1][1];
						permute_Y[i][j][k][2]=p_list[rnum1][2];
						p_list[rnum1][0]=p_list[p_list_length-1][0];
						p_list[rnum1][1]=p_list[p_list_length-1][1];
						p_list[rnum1][2]=p_list[p_list_length-1][2];
						--p_list_length;
					}
		}
		else {
			error("Error: no permutation test performed\n");
		}

		/*Implement the permutation*/
		for(i=0;i<i_levels;i++)
			for(j=0;j<j_levels;j++)
				for(k=0;k<n[i][j];k++)
					for(ii=0;ii<i_levels;ii++)
						for(jj=0;jj<j_levels;jj++)
							for(kk=0;kk<n[ii][jj];kk++)
							{
								int pi=permute_Y[i][j][k][0];
								int pj=permute_Y[i][j][k][1];
								int pk=permute_Y[i][j][k][2];
								int pii=permute_Y[ii][jj][kk][0];
								int pjj=permute_Y[ii][jj][kk][1];
								int pkk=permute_Y[ii][jj][kk][2];
								DELTA[i][j][k][ii][jj][kk]=delta[pi][pj][pk][pii][pjj][pkk];
							}
		
	}
	for(i=0;i<3;i++)
	{
		P[i][XA]*=3./(double)T;
		P[i][XB]*=3./(double)T;
		double pa = 1.-P[i][XA];
		double pb = 1.-P[i][XB];
		const double nperm = (double)T/3.;
		printf("Permutation test type %d\n",i);
		if(pa>0) printf("P value for XA    = %9.3g\t(se    = %9.3g)\n",pa,sqrt(pa*(1.-pa)/(nperm+1.)));
		else {
			pa = 1./nperm;
			printf("P value for XA    < %9.3g\t(se    = %9.3g)\n",pa,sqrt(pa*(1.-pa)/(nperm+1.)));
		}
		if(pb>0) printf("P value for XB    = %9.3g\t(se    = %9.3g)\n",pb,sqrt(pb*(1.-pb)/(nperm+1.)));
		else {
			pb = 1./nperm;
			printf("P value for XB    < %9.3g\t(se    = %9.3g)\n",pb,sqrt(pb*(1.-pb)/(nperm+1.)));
		}
		printf("\n");
	}

	return 0;
}
