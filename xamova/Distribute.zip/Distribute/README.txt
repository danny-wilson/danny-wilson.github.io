Introduction
~~~~~~~~~~~~
The program xamova extends the AMOVA (analysis of molecular variance, Excoffier et al 1992) to crossed designs where there are two factors. It does not allow nesting. An FST is estimated for each factor, and simulation-based significance tests are performed for each factor individually and the whole model.

Quick start Windows
~~~~~~~~~~~~~~~~~~~
To run the example type go to the appropriate directory using the command line (black screen) and type

xamova.exe European.txt

or

xamova.exe European.txt 10000

to increase the number of permutations. Threes types of permutation tests are performed, corresponding to the hypotheses that FST = 0 for factor 1, FST = 0 for factor 2 and FST = 0 for both. It should take less than a minute to run for 1000 permutations.

Quick start Mac
~~~~~~~~~~~~~~~
To run the example go to the appropriate directory in Terminal and type

./xamova European.txt

or

./xamova European.txt 10000

to increase the number of permutations. Threes types of permutation tests are performed, corresponding to the hypotheses that FST = 0 for factor 1, FST = 0 for factor 2 and FST = 0 for both. It should take less than a minute to run for 1000 permutations.

Input file format
~~~~~~~~~~~~~~~~~
See European.txt for an example. The format is tab-separated columns. Each row corresponds to a haplotype. The first two columns indicate the levels of the two factors. The remaining columns (one for each marker/locus/site) indicate the haplotypes. In the example they are nucleotide sequences, but they can be microsats or anything.

Files included in the distribution
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
European.txt	An example data file.
main.cpp	The source code of the program in C++
makefile	Type "make" to make the executable. You will need to modify the idir variable in makefile to point to the unzipped myutils directory.
myutils.zip	A directory of utility functions needed for compilation.
README.txt	This file.
xamova		Mac executable.
xamova.exe	Windows executable.
